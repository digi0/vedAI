# medical-parser

Deterministic parser for medical documents — lab reports, prescriptions,
visit notes. Takes a PDF, returns structured JSON. No LLM, no network.

```ts
import { parsePdf } from "medical-parser";

const bytes = await fs.readFile("./lab-report.pdf");
const doc = await parsePdf(bytes);

console.log(doc.provider);         // "smart-report-3"
console.log(doc.date);             // "2026-01-19"
console.log(doc.patient.name);     // "Sachin Garg"
console.log(doc.labValues[0]);     // { name: "LDL Cholesterol", value: 138, unit: "mg/dL", ... }
```

See [ARCHITECTURE.md](./ARCHITECTURE.md) for the design pattern this
repo uses — it's the reusable bit. To build a parser for a different
domain (invoices, bank statements, contracts, etc.), follow the porting
checklist in that doc and scaffold a sibling repo.

## Design

Each document **format** has its own provider (adapter). When you call
`parsePdf`, the package:

1. Extracts raw text from the PDF (via `pdf-parse`).
2. Asks each registered provider for a recognition confidence.
3. Lets the highest-confidence provider produce a `ParsedDocument`.
4. Falls back to a generic provider that returns text + heuristic metadata
   if no specialized provider matches.

## Currently supported providers

| Provider id        | Format                                  | Status      |
|--------------------|-----------------------------------------|-------------|
| `smart-report-3`   | Smart Report 3.0 / similar Indian preventive panels | skeleton    |
| `generic`          | Fallback — text + best-effort metadata  | usable      |

## CLI

```bash
npm run parse -- ./test-docs/foo.pdf            # full structured output
npm run parse -- ./test-docs/foo.pdf --text-only  # just the raw text
npm run parse -- ./test-docs/foo.pdf --pages      # per-page previews
```

Drop test PDFs into `./test-docs/` (gitignored).
