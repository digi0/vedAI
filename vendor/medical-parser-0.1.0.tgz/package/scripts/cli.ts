#!/usr/bin/env tsx
/**
 * medical-parser CLI.
 *
 *   npm run parse -- ./test-docs/foo.pdf
 *   npm run parse -- ./test-docs/foo.pdf --text-only
 *   npm run parse -- ./test-docs/foo.pdf --pages
 */

import { parsePdfFile, extractText } from "../src/index";
import { readFile } from "node:fs/promises";
import { basename } from "node:path";

async function main() {
  const args = process.argv.slice(2);
  const path = args.find((a) => !a.startsWith("--"));
  if (!path || args.includes("--help")) {
    console.log(
      "Usage: npm run parse -- <file.pdf> [--text-only] [--pages] [--raw-text]\n" +
        "  --text-only   Print extracted text only (no provider parse)\n" +
        "  --pages       Print per-page text (first 200 chars each)\n" +
        "  --raw-text    Include full rawText in the JSON output",
    );
    process.exit(path ? 0 : 1);
  }

  const bytes = await readFile(path);
  const t0 = Date.now();

  if (args.includes("--text-only")) {
    const extracted = await extractText(bytes);
    console.log(`📄 ${basename(path)} · ${extracted.pageCount} pages · ${extracted.text.length} chars\n`);
    console.log(extracted.text);
    return;
  }

  if (args.includes("--pages")) {
    const extracted = await extractText(bytes);
    console.log(`📄 ${basename(path)} · ${extracted.pageCount} pages\n`);
    extracted.pages.forEach((p, i) => {
      const preview = p.slice(0, 200).replace(/\s+/g, " ");
      console.log(`--- page ${i + 1} (${p.length} chars) ---`);
      console.log(preview + (p.length > 200 ? "…" : ""));
      console.log();
    });
    return;
  }

  const parsed = await parsePdfFile(path);
  const elapsed = ((Date.now() - t0) / 1000).toFixed(2);

  const out: Record<string, unknown> = { ...parsed };
  if (!args.includes("--raw-text")) {
    out.rawText = `<omitted, ${parsed.rawText.length} chars; pass --raw-text to include>`;
  }

  console.log(JSON.stringify(out, null, 2));
  console.error(`\n✓ ${parsed.provider} (confidence ${parsed.confidence.toFixed(2)}) in ${elapsed}s`);
}

main().catch((err) => {
  console.error("✗", err.message);
  process.exit(1);
});
