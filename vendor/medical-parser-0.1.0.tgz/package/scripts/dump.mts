#!/usr/bin/env tsx
/**
 * Inspection helper. Run after parsing to dump the JSON output AND a
 * per-page text dump side-by-side so you can spot-check the parser
 * against the original PDF.
 *
 *   npm run dump -- ./test-docs/foo.pdf
 *
 * Writes:
 *   <file>.parsed.json   — full ParsedDocument
 *   <file>.pages.txt     — per-page extracted text
 *   <file>.review.md     — markdown table pairing each labValue with the
 *                          page it likely came from, sorted by flag so
 *                          the ones most worth verifying float to the top
 */

import { parsePdfFile, extractText } from "../src/index";
import { readFile, writeFile } from "node:fs/promises";
import { basename, dirname, join } from "node:path";

async function main() {
  const path = process.argv[2];
  if (!path) {
    console.error("Usage: npm run dump -- <file.pdf>");
    process.exit(1);
  }

  const stem = basename(path).replace(/\.pdf$/i, "");
  const dir = dirname(path);
  const jsonPath = join(dir, `${stem}.parsed.json`);
  const pagesPath = join(dir, `${stem}.pages.txt`);
  const reviewPath = join(dir, `${stem}.review.md`);

  console.log(`📄 Parsing ${basename(path)}…`);

  const bytes = await readFile(path);
  const [parsed, extracted] = await Promise.all([
    parsePdfFile(path),
    extractText(bytes),
  ]);

  // 1. JSON dump — omit rawText so the file is reviewable
  const slim = { ...parsed, rawText: undefined };
  await writeFile(jsonPath, JSON.stringify(slim, null, 2));

  // 2. Per-page text dump
  const pageDump = extracted.pages
    .map(
      (p, i) =>
        `\n\n=== page ${i + 1} (${p.length} chars) ===\n\n${p}`,
    )
    .join("\n");
  await writeFile(pagesPath, pageDump.trimStart());

  // 3. Review markdown — each value with the page it most likely came from
  const lines: string[] = [
    `# Parser review — ${basename(path)}`,
    ``,
    `**Provider:** ${parsed.provider} (confidence ${parsed.confidence.toFixed(2)})`,
    `**Patient:** ${parsed.patient.name ?? "?"} · ${parsed.patient.age ?? "?"}y · ${parsed.patient.sex ?? "?"}`,
    `**Date:** ${parsed.date ?? "?"}`,
    `**Summary:** ${parsed.summary || "(none extracted)"}`,
    ``,
    `Cross-check by opening the PDF and the \`*.pages.txt\` file side by side.`,
    ``,
    `## Lab values (${parsed.labValues.length})`,
    ``,
    `| # | Page | Test | Value | Unit | Range | Flag |`,
    `|---|------|------|-------|------|-------|------|`,
  ];

  for (let i = 0; i < parsed.labValues.length; i++) {
    const v = parsed.labValues[i]!;
    // Find the page that contains both the test name AND the value.
    const needleName = String(v.name).slice(0, 16).toLowerCase();
    const needleValue = String(v.value);
    let pageMatch = "?";
    for (let p = 0; p < extracted.pages.length; p++) {
      const txt = extracted.pages[p]!.toLowerCase();
      if (txt.includes(needleName) && txt.includes(needleValue)) {
        pageMatch = String(p + 1);
        break;
      }
    }
    const cell = (s: string | number | null | undefined) =>
      (s ?? "").toString().replace(/\|/g, "\\|").replace(/\n/g, " ");
    const flagEmoji =
      v.flag === "high"
        ? "🔺 high"
        : v.flag === "low"
          ? "🔻 low"
          : v.flag === "normal"
            ? "✅ normal"
            : v.flag === "critical"
              ? "🚨 critical"
              : "—";
    lines.push(
      `| ${i + 1} | ${pageMatch} | ${cell(v.name)} | ${cell(v.value)} | ${cell(v.unit)} | ${cell((v.referenceRange ?? "").slice(0, 60))} | ${flagEmoji} |`,
    );
  }

  await writeFile(reviewPath, lines.join("\n") + "\n");

  console.log(`✓ wrote:`);
  console.log(`  ${jsonPath}`);
  console.log(`  ${pagesPath}`);
  console.log(`  ${reviewPath}`);
  console.log(``);
  console.log(`Open the PDF (\`open "${path}"\`) and the review.md or pages.txt`);
  console.log(`side-by-side to spot-check.`);
}

main().catch((e) => {
  console.error("✗", e.message);
  process.exit(1);
});
